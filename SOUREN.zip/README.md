fast of all you have to open terminal and write "npm run dev" and you can see UI calander and if you click any date and you see a popup and if you want to add event and add it and save it.
if you want to change event and click this event and update it and if you want to delete so click  the delete botton.


if you want to see browser this is vercel link:-